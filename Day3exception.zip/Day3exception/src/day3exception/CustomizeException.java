/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3exception;

/**
 *
 * @author macstudent
 */
class testException extends Exception{
    public testException(String message) {
        super(message);
    }
}
public class CustomizeException {
    public static void main(String args[]) throws Exception{ //throws always used with method if method has exception
        int n1 = 10;
        try{
            if(n1 == 10){
                throw new testException("Test insuccessful");
            }
        }catch(testException e){
            System.out.println("customized exception");
            System.out.println(e.getMessage());
            System.out.println(e.getStackTrace()); //it works with hirarchy it shows with method throw exception
            
        }
    }
    
}
