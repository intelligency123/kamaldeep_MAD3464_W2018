/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4arraylisttest;

import java.util.Comparator;

/**
 *
 * @author macstudent
 */
public class Students {
    int studentID;
    String studentName;
    double percentage;
    Students(){
        this.studentID = 0;
        this.studentName = "Unknown";
        this.percentage = 0;
    }
    Students( int studentsID,String studentName,double percentage){
        this.studentID = studentsID;
        this.studentName = studentName ;
        this.percentage = percentage;
    }
    void setID(int ID){
        this.studentID = ID;
    }
    int getID(){
       return this.studentID;
    }
    void setName(String Name){
        this.studentName = Name;
    }
     String getName(){
       return this.studentName;
    }
    void setpercentage(double percent){
        this.percentage = percent;
    }
    double getpercentage(){
       return this.percentage;
    }
    
    void displayInfo(){
        System.out.println("studentID : " +this.studentID + "\n STUDENTname : " +this.studentName + "\n percentage : " +this.percentage);
    }
    
}
class studentsPercentage implements Comparator<Students>{

    @Override
    public int compare(Students o1, Students o2) {
        if(o1.percentage == o2.percentage)
            return 0;
        
       else if(o1.percentage < o2.percentage)
            return 1;
        else
           return -1;
    }
    
}