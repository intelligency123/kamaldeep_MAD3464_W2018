/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4arraylisttest;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/**
 *
 * @author macstudent
 */
public class Day4ArrayListtest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Books book1 = new Books(1,"the Sky",8);
        Books book2 = new Books(2,"Necklace",3);
        Books book3 = new Books(3,"Milk",2);
        Books book4 = new Books(4,"Journey",3);
        Books book5 = new Books(5,"Wondrer",4);
        ArrayList<Books> library = new ArrayList<Books>();
        library.add(book1);
         library.add(book2);
          library.add(book3);
           library.add(book4);
            library.add(book5);
            System.out.println("No. of books : " + library.size());
            library.add(2,new Books(10,"Pecific",9));
           
           library.forEach(bk ->{
               //bk.displayInfo();
           });
           Collections.sort(library,new bookRatingComparator());
           Collections.sort(library,new bookTitleComparator());
           for(Books bk : library){
               bk.displayInfo();          
           }
    
    Students student1  = new Students(1,"kamal",90);
    Students student2  = new Students(2,"prabh",90.12);
    Students student3  = new Students(3,"nav",90);
    ArrayList<Students> studentdetail = new ArrayList<Students>();
    studentdetail.add(student1);
    studentdetail.add(student2);
    studentdetail.add(student3);
    studentdetail.add(3,new Students(5,"sukh",90.1));
    Collections.sort(studentdetail,new studentsPercentage());
    studentdetail.forEach(sk ->{
        sk.displayInfo();
    });
    }       
}
