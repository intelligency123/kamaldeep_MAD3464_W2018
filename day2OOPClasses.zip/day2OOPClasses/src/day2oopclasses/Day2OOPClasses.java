/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2oopclasses;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Day2OOPClasses {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //create new object of bank class
        Bank myBank = new Bank();
        System.out.println("Bank ID : " + myBank.bankId);
        System.out.println("Bank Name : " +myBank.bankName);
        
        Bank yourBank = new Bank();
        myBank.bankId = 1231;
        myBank.bankName = "RBC";
        System.out.println("Bank ID : " + myBank.bankId);
        System.out.println("Bank Name : " +myBank.bankName);
        myBank.getbankName();
        yourBank.setBankName("ICICI");
        yourBank.getbankName();
        
        Scanner myInput = new Scanner(System.in); //scanner for getting input
        String name;
        System.out.println("Enter bank Name : ");
        name = myInput.nextLine(); // for string input method is nextline
        yourBank.setBankName(name);
        yourBank.getbankName();
        
        //create object of arithmetic class
        Arithmetic operation1 = new Arithmetic();
        //operation1.addition(10, 20);
        System.out.println("Output of integer addition : "+ operation1.addition(10, 20));
        System.out.println("Output of float addition : "+ operation1.addition(10.23f, 20.23f));
        System.out.println("Output of  three integer addition : "+ operation1.addition(10, 20,30));
        System.out.println("Output of multiplication : "+ operation1.multiplication(10, 20,30));
        Arithmetic.multiplication(10,20);
       // Arithmetic.addition(10,20);
       Arithmetic.n1 = 20;
       //Arithmetic.n2 = 20; // only static object can access withinn static
       System.out.println(Arithmetic.n1 + " " + Arithmetic.n2);
    }
    
}
