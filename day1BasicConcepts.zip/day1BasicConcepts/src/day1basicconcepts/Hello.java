
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day1basicconcepts;
import java.util.Arrays;

/**
 *
 * @author macstudent
 */
public class Hello {
    public static void main(String[] args){
        
        int number = 10;
        float percentage;
        char vowel = 'a';
        String firstName = "kk";
        
        System.out.println("Value of number : " + number); //system is class in java that gives us different funtionalities to perform on system 
        percentage = 78.6f;
        System.out.println("Value of percentage :" + percentage);
        System.out.println("Vowel = " + vowel);
        System.out.println("firstname : " + firstName);
        percentage = 10;
        //number = 10.23;
        vowel = 35;
        number = 20;
        System.out.println("Vowel = " + vowel);
        System.out.println("Value of number : " + number);
        System.out.println( 1 + 2 + "test");
        System.out.println( "test " + 1 + 2 );
        
        if (number > 10){
            System.out.println("more than 10");
        }
        else if (number == 10) {
            System.out.println( "equal to 10");
            
        }
        
        switch(number){  //or switch(10+20)
            case 10:
                System.out.println( "value is 10");
                break;
                case 20:
                System.out.println( "value is 20");
                break;
                case 30:
                System.out.println( "value is 30");
                break;
                default:
                    System.out.println("No matching value");
                
        }
        vowel = 'a';
        switch(vowel){
            case ('a' | 'i' | 'e' | 'o'| 'u'):
          //  case 'i':
          //  case 'e':
           // case 'o':
          //  case 'u':
                System.out.println("vowel");
                break;
            default:
                System.out.println("Not a vowel");
                break;
        }
        String province = "Alberta";
        switch(province){
            case "ontario" :
                System.out.println("ON");
                break;
                case "Alberta" :
                System.out.println("AB");
                break;
                case "Prince Edward" :
                System.out.println("PE");
                break;
                default :
                    System.out.println("unavailable");
                    break;
        }
        int numbers[] = new int [5];
        int i;
        for(i=0;i<numbers.length;i++){
            numbers[i] = (int)(Math.random()*100);
            System.out.println("numbers ["+ i +"] = "+numbers[i]);
            
        }
       double PI_VALUE =  Math.PI; // for contant all letter must be capital seperated different name with _
         double power = Math.pow(2, 2);
         Math.sqrt(144);
         Math.abs(PI_VALUE);
         float grades[][] = new float [3][4];
         for(i=0;i<3;i++){
             for(int j=0;j<4;j++){
                 grades[i][j] = 10.0f;
             }
         }
         int randomNo[] = new int[10];
         for(i=0;i<10;i++){
             randomNo[i] = (int)(Math.random()*10);
             System.out.println("no " +(i+1) + " = " +randomNo[i]);
         }
         Arrays.sort(randomNo);
         for(i=0;i<10;i++){
             System.out.println("no " +(i+1) + " = " +randomNo[i]);
         }
         
         
        int n = 5;
    for(int a=1;a<=n;a++)
    {
      for(int b=1;b<=n;b++)
      {
      if((b==1 || b==n) || (a==1 || a==n))
      {
         System.out.print(" *");//1 space
      }else
      {
          System.out.print("  ");//2 spaces
      }
      }
      System.out.println();
    }
}
}
