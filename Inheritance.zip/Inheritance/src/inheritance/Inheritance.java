/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author macstudent
 */
public class Inheritance {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Person one = new Person();
        //one.readData();
        //one.displayData();
        Person kamal = new Person("kamal","deep",12);
        //kamal.displayData();
        Person kamal2 = new Person(kamal);
        //kamal2.displayData();
        
//        Employee e1 = new Employee(1450.87);
//        e1.display();
//        
        Employee e2 = new Employee();
        e2.display();
        e2.firstName = "kk";
        e2.lastName = "deep";
        e2.age = 10;
        e2.salary = 1000;
        e2.display();
       // e2.displayData();
                
       // System.out.println("last name : " + e2.lastName);
        Employee E3 = new Employee();
        E3.read();
            E3.display();
    }
    
}

