/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4;

/**
 *
 * @author macstudent
 */
public class Day4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      //  shape obj1 = new shape(); any class which is declare as abstract don't allow us to create object
      Circle c1 = new Circle();
      c1.draw();
      c1.display("its a circle!!");
        
    }
    
}

abstract class shape{
    int x;
    int y;
    
  abstract  void draw();//when method don't have body declare it as abstract
  
  void display(String msg){
      System.out.println(msg);
  }
    
}
 class Circle extends shape{

    @Override
    void draw() {
        System.out.println("Drawing circle");
        super.x = 20;
        super.y = 30;
    
     System.out.println("x = " +super.x + " y = " +super.y);
             }
 }
abstract class Rectangle extends shape{
    int h;
    abstract void draw();
}