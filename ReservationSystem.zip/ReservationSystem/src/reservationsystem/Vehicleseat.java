/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reservationsystem;



/**
 *
 * @author master
 */
public class Vehicleseat {
 int seat[] = new int[10];
   Vehicleseat(){
       int i;
       for(i=0;i<=9;i++){
           seat[i] = 0;
           System.out.println("Seat "+(i+1)+" before reservstion : " + seat[i]);
       }
       
       
   }  
        void assignseat(int reserve){
      int a;
       for( a =0;a<=9;a++){
          if(a < reserve){
             seat[a] = 1;
              System.out.println("Seating plane after reservation: " + seat[a]);
          }
          if(a >= reserve){
          seat[a] = 0;
           System.out.println("Seating plane after reservation : " + seat[a]);
                }
       }
      
//        
   }
   void seatingcapacity(int capacity){
       if (10 - capacity <= 10){
           System.out.println("Available seats are : " + (10 - capacity));
       }
       else{
          System.out.println("no more seat is available");
      }
  }
//    
}
