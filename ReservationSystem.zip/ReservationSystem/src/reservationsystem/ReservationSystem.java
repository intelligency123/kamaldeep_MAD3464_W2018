/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reservationsystem;

import java.util.Scanner;

/**
 *
 * @author master
 */
public class ReservationSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      //  Vehicleseat vs = new Vehicleseat();
       
      // System.out.println("how many seats u want to reserve");
      Scanner input = new Scanner(System.in);
      //  int reserveseat = input.nextInt();
      // vs.assignseat(reserveseat);
      //  vs.seatingcapacity(reserveseat);
        
        Airlinereservation airline = new Airlinereservation();
        System.out.println("Please type 1 for smoking or Type 2 for non-smoking");
        int airlinereserve = input.nextInt();
        if(airlinereserve == 1){
            airline.smoking();
             airline.smoking();
              airline.smoking();
               airline.smoking();
                airline.smoking();
                 airline.smoking();
                 
        }else if(airlinereserve == 2){
            airline.nonsmoking();
        }
        
    }
    
}
