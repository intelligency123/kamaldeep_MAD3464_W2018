/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reservationsystem;

import java.util.Scanner;

/**
 *
 * @author master
 */
public class Airlinereservation {
    int airline[] = new int[11];
    void smoking(){
        
        int seat;
        for(seat=1;seat<=5;seat++){
            if(airline[seat] == 0){
                airline[seat] = 1;
                System.out.println("Boarding pass ");
                System.out.println("Seat number is : " +seat);
                System.out.println("Reservation area : Smoking");
                break;
            }else if (airline[5] == 1){
                System.out.println("Flight is full you want to make resevation in non-smoking ");
                Scanner input = new Scanner(System.in);
                String answer = input.nextLine();
                if("yes".equals(answer)){
                    nonsmoking();
                 break;
                }else if ("no".equals(answer)){
                   System.out.println("Next flight is after 3 hour");
                   break;
                }
            }
            
        }
    }
    void nonsmoking(){
        int seat;
        for(seat=6;seat<=10;seat++){
            if(airline[seat] == 0){
                airline[seat] = 1;
                System.out.println("Boarding Pass ");
                System.out.println("Seat number is : " +seat);
                System.out.println("Reservation area : non-smoking");
                break;
            }else if (airline[10] == 1){
                System.out.println("Flight is full you want to make resevation in smoking ");
                Scanner input = new Scanner(System.in);
                String answer = input.nextLine();
                if("yes".equals(answer)){
                    smoking();
                    break;
                }else if("no".equals(answer)){
                   System.out.println("Next flight is after 3 hour");
                   break;
                }
            }
            
        }
        
        
    }
    
}
