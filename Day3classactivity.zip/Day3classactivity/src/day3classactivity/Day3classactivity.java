/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3classactivity;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Day3classactivity {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Faculty f = new Faculty();
        f.readdata();
        
        f.readvalue();
        
        f.getdata();
        
       f.displaydata();
       f.displayvalue();
        f.setdata();
    }
    
}
interface Persondata{
   void readdata();
   void displaydata();
    
}
interface Employeedata{
   
    
   void readvalue();
   void displayvalue();
    
}
interface Facultydata{
   void getdata();
   void setdata();
    
}
class Person implements Persondata{
    String name;
    int age;
   Scanner input = new Scanner(System.in);

    @Override
    public void readdata() {
        System.out.println("Enter Name");
        name = input.nextLine();
        System.out.println("Enter age");
         age = input.nextInt();
    }

    @Override
    public void displaydata() {
        System.out.println("person name is : " +name);
        System.out.println("person age is : " +age);
    }
    
}
//class Employee implements Employeedata{
//    //String type;
//    double salary;
//   Scanner input = new Scanner(System.in);
//
//    @Override
//    public void readvalue() {
//        System.out.println("Enter type(PT/FT)");
//        type = input.nextLine();
//        System.out.println("Enter salary");
//         salary = input.nextDouble();
//    }
//
//    @Override
//    public void displayvalue() {
//        System.out.println("person type is : " +type);
//        System.out.println("person salary is : " +salary);
//    }
//    
//}
class Faculty extends Person implements Facultydata,Employeedata {
    String course;
    String type;
  double salary;
   Scanner input = new Scanner(System.in);

    @Override
    public void getdata() {
        System.out.println("Enter course");
        course = input.nextLine();
        
    }

    @Override
    public void setdata() {
        System.out.println("person course is : " +course);
        
    }

    @Override
    public void readvalue() {
          System.out.println("Enter type(PT/FT)");
        type = input.nextLine();
       System.out.println("Enter salary");
       salary = Double.parseDouble(input.nextLine());
    }

    @Override
    public void displayvalue() {
        System.out.println("person type is : " +type);
       System.out.println("person salary is : " +salary);
    }
    
}